Instructions for configuring SSH & wifi details

1. Modify wpa_supplicant.conf with wifi details
2. Add wpa_supplicant.conf and ssh file to SD card
3. Insert SD card to RPI
4. Ping raspberrypi.local to get the IP address of the RPI
or nmap-sn <network-address>/<subnet-mask>
eg: nmap -sn 192.168.1.0/24

Make sure the terminal and raspberry pi are connected to the same network
5. ssh <raspberrypi.hostname>@<raspberrypi.local IP>
credentials: admin:P@ssw0rd